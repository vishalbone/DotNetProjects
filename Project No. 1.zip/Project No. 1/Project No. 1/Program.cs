﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_No._1
{
    class swapArray
    {
        static void disp(int[] arr)
        {
            for (int i = 0; i < 25; i++)
            {
                Console.Write(arr[i] + " ");
                if (i == 4 || i == 9 || i == 14 || i == 19)
                    Console.Write("\n");
            }
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Program Start...");
            int[] arr = new int[25];
            int loc, ch;
            for (int i = 0; i < 25; i++)
                arr[i] = 0;

            disp(arr);
            Console.WriteLine();
            Console.Write("Enter start location :");
            loc = int.Parse(Console.ReadLine());
            Console.Write("Entered location :" + loc + "\n");
            while (true)
            {
                Console.WriteLine();
                Console.WriteLine("-----------------------------------------------------");
                Console.WriteLine("Enter the Choice between 2 or 6 or 4 or 8");
                Console.WriteLine();
                Console.WriteLine("2 is for Down");
                Console.WriteLine("8 is for UP");
                Console.WriteLine("4 is for Left");
                Console.WriteLine("6 is for Right");
                Console.WriteLine("Enter 5 for log out from program");
                Console.WriteLine("-----------------------------------------------------");
                Console.WriteLine("Enter your choice: ");
                ch = int.Parse(Console.ReadLine());
                if (ch == 8)
                {
                    loc = loc - 5;
                    if (loc >= 0)
                    {
                        loc = loc + 5;
                        arr[loc] = 0;
                        loc = loc - 5;
                        arr[loc] = 1;
                    }
                    else
                    {
                        loc = loc + 5;
                        Console.WriteLine("out of boundary....Enter correct choice: ");
                    }
                    Console.WriteLine("-----------------------------------------------------------------");
                }

                else if (ch == 4)
                {
                    if (loc >= 0 && loc <= 4)
                    {
                        loc--;
                        if (loc >= 0)
                        {
                            loc++;
                            arr[loc] = 0;
                            loc--;
                            arr[loc] = 1;
                        }
                        else
                        {
                            loc++;
                            Console.WriteLine("out of boundary....Enter correct choice: ");
                        }
                        Console.WriteLine("-----------------------------------------------------------------");
                    }
                    else if (loc >= 5 && loc <= 9)
                    {
                        loc--;
                        if (loc >= 5)
                        {
                            loc++;
                            arr[loc] = 0;
                            loc--;
                            arr[loc] = 1;
                        }
                        else
                        {
                            loc++;
                            Console.WriteLine("out of boundary....Enter correct choice: ");
                        }
                        Console.WriteLine("-----------------------------------------------------------------");
                    }
                    else if (loc >= 10 && loc <= 14)
                    {
                        loc--;
                        if (loc >= 10)
                        {
                            loc++;
                            arr[loc] = 0;
                            loc--;
                            arr[loc] = 1;
                        }
                        else
                        {
                            loc++;
                            Console.WriteLine("out of boundary....Enter correct choice: ");
                        }
                        Console.WriteLine("-----------------------------------------------------------------");
                    }
                    else if (loc >= 15 && loc <= 19)
                    {
                        loc--;
                        if (loc >= 15)
                        {
                            loc++;
                            arr[loc] = 0;
                            loc--;
                            arr[loc] = 1;
                        }
                        else
                        {
                            loc++;
                            Console.WriteLine("out of boundary....Enter correct choice: ");
                        }
                        Console.WriteLine("-----------------------------------------------------------------");
                    }
                    else // if(loc>=20 && loc<=24)
                    {
                        loc--;
                        if (loc >= 20)
                        {
                            loc++;
                            arr[loc] = 0;
                            loc--;
                            arr[loc] = 1;
                        }
                        else
                        {
                            loc++;
                            Console.WriteLine("out of boundary....Enter correct choice: ");
                        }
                        Console.WriteLine("-----------------------------------------------------------------");
                    }
                }
                else if (ch == 6)
                {
                    if (loc >= 0 && loc <= 4)
                    {
                        loc++;
                        if (loc <= 4)
                        {
                            loc--;
                            arr[loc] = 0;
                            loc++;
                            arr[loc] = 1;
                        }
                        else
                        {
                            loc--;
                            Console.WriteLine("out of boundary....Enter correct choice: ");
                        }
                        Console.WriteLine("-----------------------------------------------------------------");
                    }
                    else if (loc >= 5 && loc <= 9)
                    {
                        loc++;
                        if (loc <= 9)
                        {
                            loc--;
                            arr[loc] = 0;
                            loc++;
                            arr[loc] = 1;
                        }
                        else
                        {
                            loc--;
                            Console.WriteLine("out of boundary....Enter correct choice: ");
                        }
                        Console.WriteLine("-----------------------------------------------------------------");
                    }
                    else if (loc >= 10 && loc <= 14)
                    {
                        loc++;
                        if (loc <= 14)
                        {
                            loc--;
                            arr[loc] = 0;
                            loc++;
                            arr[loc] = 1;
                        }
                        else
                        {
                            loc--;
                            Console.WriteLine("out of boundary....Enter correct choice: ");
                        }
                        Console.WriteLine("-----------------------------------------------------------------");
                    }
                    else if (loc >= 15 && loc <= 19)
                    {
                        loc++;
                        if (loc <= 19)
                        {
                            loc--;
                            arr[loc] = 0;
                            loc++;
                            arr[loc] = 1;
                        }
                        else
                        {
                            loc--;
                            Console.WriteLine("out of boundary....Enter correct choice: ");
                        }
                        Console.WriteLine("-----------------------------------------------------------------");
                    }
                    else // if(loc>=20 && loc<=24)
                    {
                        loc++;
                        if (loc <= 24)
                        {
                            loc--;
                            arr[loc] = 0;
                            loc++;
                            arr[loc] = 1;
                        }
                        else
                        {
                            loc--;
                            Console.WriteLine("out of boundary....Enter correct choice: ");
                        }
                        Console.WriteLine("-----------------------------------------------------------------");
                    }
                }
                else if (ch == 2)
                {
                    loc = loc + 5;
                    if (loc <= 24)
                    {
                        loc = loc - 5;
                        arr[loc] = 0;
                        loc = loc + 5;
                        arr[loc] = 1;
                    }
                    else
                    {
                        loc = loc - 5;
                        Console.WriteLine("out of boundary....Enter correct choice: ");
                    }
                    Console.WriteLine("-----------------------------------------------------------------");
                }
                else if (ch == 5)
                {
                    Console.WriteLine("You have successfully loged out from the program");
                    Console.WriteLine("-----------------------------------------------------------------");
                    break;
                }
                else
                {
                    Console.WriteLine("You have entered wrong choice...");
                }
                disp(arr);
            }
        }
    }
}