﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InfoModel
{
    class Program
    {
        public static Country GetCountryDetails()
        {
            Country cu = new Country();
            Console.Write("Enter the Country ID = ");
            cu.IdCountry = int.Parse(Console.ReadLine());
            Console.Write("Enter the Country Name = ");
            cu.CountryName = Console.ReadLine();

            return cu;
        }
        public static City GetCityDetails()
        {
            City ct = new City();
            Console.WriteLine("Enter the City ID");
            ct.IdCity = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the City Name");
            ct.CityName = Console.ReadLine();
            Console.WriteLine("Enter the Country ID");
            ct.IdCountry = int.Parse(Console.ReadLine());

            return ct;
        }
        public static Address GetAddressDetails()
        {
            Address a = new Address();
            Console.WriteLine("Enter the Address ID");
            a.IdAddress = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the Address 1");
            a.Address1 = Console.ReadLine();
            Console.WriteLine("Enter the Address 2");
            a.Address2 = Console.ReadLine();
            Console.WriteLine("Enter the Address 3");
            a.Address3 = Console.ReadLine();
            Console.WriteLine("Enter the Postal Code");
            a.PostalCode = Console.ReadLine();
            Console.WriteLine("Enter the City ID");
            a.IdCity = int.Parse(Console.ReadLine());

            return a;
        }
        public static Building GetBuildingDetails()
        {
            Building b = new Building();
            Console.WriteLine("Enter the Building ID");
            b.IdBuilding = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the Floor Number");
            b.FloorNumber = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the Latitude");
            b.Latitude = decimal.Parse(Console.ReadLine());
            Console.WriteLine("Enter the Latitude");
            b.Longitude = decimal.Parse(Console.ReadLine());
            Console.WriteLine("Enter the Address ID");
            b.IdAddress = int.Parse(Console.ReadLine());

            return b;
        }
        public static Room GetRoomDetails()
        {
            Room r = new Room();
            Console.WriteLine("Enter the Room ID");
            r.IdRoom = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the Owner name");
            r.name =Console.ReadLine();
            Console.WriteLine("Enter the Description");
            r.description=Console.ReadLine();
            Console.WriteLine("Enter the Capacity");
            r.capacity = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the Enabled");
            r.enabled = byte.Parse(Console.ReadLine());
            Console.WriteLine("Enter the note");
            r.note = Console.ReadLine();
            Console.WriteLine("Enter the Smart");
            r.smart = byte.Parse(Console.ReadLine());
            Console.WriteLine("Enter the Building ID");
            r.IdBuilding = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the Floor");
            r.floor = int.Parse(Console.ReadLine());

            return r;
        }
        public static void display(Country c)
        {
            Console.WriteLine("{0}\t{1}",c.IdCountry,c.CountryName);
        }
        public static void display(City c)
        {
            Console.WriteLine($"{c.IdCity}\t{c.CityName}\t\t{c.Country.CountryName}");
        }
        public static void display(Address c)
        {
            Console.WriteLine($"{c.IdAddress}\t{c.Address1}\t\t{c.Address2}\t{c.Address3}\t\t{c.PostalCode}\t\t{c.City.CityName}\t\t{c.City.Country.CountryName}");
        }
        public static void display(Building c)
        {
            Console.WriteLine($"{c.IdBuilding}\t{c.FloorNumber}\t\t{c.Latitude}\t{c.Longitude}\t{c.Address.Address1}\t\t{c.Address.PostalCode}\t\t{c.Address.City.CityName}\t\t{c.Address.City.Country.CountryName}");
        }
        public static void display(Room c)
        {
            Console.WriteLine($"{c.IdRoom}\t{c.name}\t{c.description}\t{c.capacity}\t\t{c.enabled}\t\t{c.Building.Address.City.CityName}\t\t\t{c.Building.Address.City.Country.CountryName}");
        }

        static void Main(string[] args)
        {
            InfoDatabaseEntities db = new InfoDatabaseEntities();
            int ch;
            Console.WriteLine("1 Insert\n2 Display\n3 Update\n4 Delete\n5 Exit");
            Console.WriteLine("Enter the choice");
            ch = int.Parse(Console.ReadLine());
            while (ch != 5) 
            {
                Country cut; City ct; Address ad; Building bi; Room r;
                switch (ch)
                {
                    case 1:
                        Console.WriteLine("\n1 Insert to Country\n2 Insert to City\n3 Insert to Address\n4 Insert to Building\n5 Insert to Room\n6 Main menu");
                        ch = int.Parse(Console.ReadLine());
                        while(ch != 6)
                        {
                            Console.WriteLine("\n1 Insert to Country\n2 Insert to City\n3 Insert to Address\n4 Insert to Building\n5 Insert to Room\n6 Main menu");
                            Console.WriteLine("Enter the Choice");
                            ch = int.Parse(Console.ReadLine());
                            switch (ch)
                            {
                                case 1:  Country cou = GetCountryDetails();
                                    db.Countries.Add(cou);
                                    db.SaveChanges();
                                    Console.WriteLine("Inserted successfully");
                                    break;
                                case 2: City city = GetCityDetails();
                                    db.Cities.Add(city);
                                    db.SaveChanges();
                                    break;
                                case 3: Address add = GetAddressDetails();
                                    db.Addresses.Add(add);
                                    db.SaveChanges();
                                    Console.WriteLine("Inserted Successfully");
                                    break;
                                case 4: Building build = GetBuildingDetails();
                                    db.Buildings.Add(build);
                                    db.SaveChanges();
                                    break;
                                case 5: Room room = GetRoomDetails();
                                    db.Rooms.Add(room);
                                    db.SaveChanges();
                                    break;
                                case 6: break;
                                default: Console.WriteLine("Invalid choice");break;
                            }
                        }
                        break;
                    case 2:
                        Console.WriteLine("\n1 Display Country\n2 Display City\n3 IDisplay Address\n4 Display Building\n5 Display Room\n6 Main menu");
                        ch = int.Parse(Console.ReadLine());
                        while(ch!=6)
                        {
                            switch(ch)
                            {
                                case 1:
                                    Console.WriteLine("1. Specific Record\n2. All Record");
                                    ch = int.Parse(Console.ReadLine());
                                    int id;
                                    if (ch == 1)
                                    {
                                        Console.WriteLine("Enter the Country Id");
                                        id = int.Parse(Console.ReadLine());
                                        List<Country> cl = db.specificcontryrecord(id).ToList<Country>();
                                        if (cl.Count == 0)
                                        {
                                            Console.WriteLine("Not Valid : Enter Correct Choice");
                                            Console.WriteLine("1 Insert\n2 Display\n3 Update\n4 Delete\n5 Exit");
                                            Console.WriteLine("Enter the choice");
                                            ch = int.Parse(Console.ReadLine());
                                        }
                                        else
                                        {
                                            Console.WriteLine("ID\tCOUNTRY NAME");
                                            Console.WriteLine("___________________________________");
                                            foreach (Country c1 in db.specificcontryrecord(id))
                                            {
                                                display(c1);
                                            }
                                            Console.WriteLine("1 Insert\n2 Display\n3 Update\n4 Delete\n5 Exit");
                                            Console.WriteLine("Enter the choice");
                                            ch = int.Parse(Console.ReadLine());
                                        }
                                    }
                                    if (ch == 2)
                                    {
                                        Console.WriteLine("ID\tCOUNTRY NAME");
                                        Console.WriteLine("___________________________________");
                                        foreach (Country c1 in db.allcontryrecord())
                                        {
                                            display(c1);
                                        }
                                        Console.WriteLine("1 Insert\n2 Display\n3 Update\n4 Delete\n5 Exit");
                                        Console.WriteLine("Enter the choice");
                                        ch = int.Parse(Console.ReadLine());
                                    }
                                    else
                                    {
                                        Console.WriteLine("Invalid Choice");
                                    }
                                    break;
                                case 2:
                                    Console.WriteLine("1. Specific Record\n2. All Record");
                                    ch = int.Parse(Console.ReadLine());
                                    int cid;
                                    if (ch == 1)
                                    {
                                        Console.WriteLine("Enter the CITY Id");
                                        cid = int.Parse(Console.ReadLine());
                                        List<City> cl = db.specfCityRecord(cid).ToList<City>();
                                        if (cl.Count == 0)
                                        {
                                            Console.WriteLine("Not Valid : Enter Correct Choice");
                                            Console.WriteLine("1 Insert\n2 Display\n3 Update\n4 Delete\n5 Exit");
                                            Console.WriteLine("Enter the choice");
                                            ch = int.Parse(Console.ReadLine());
                                        }
                                        else
                                        {
                                            Console.WriteLine("ID\tCITY NAME\tCOUNTRY NAME");
                                            Console.WriteLine("___________________________________");
                                            foreach (City c1 in db.specfCityRecord(cid))
                                            {
                                                display(c1);
                                            }
                                        }
                                    }
                                    if (ch == 2)
                                    {
                                        Console.WriteLine("ID\tCITY NAME\tCOUNTRY NAME");
                                        Console.WriteLine("___________________________________");
                                        foreach (City c1 in db.allCityRecord())
                                        {
                                            display(c1);
                                        }
                                    }
                                    else
                                    {
                                        Console.WriteLine("Invalid Choice");
                                    }
                                    break;
                                case 3:
                                    Console.WriteLine("1. Specific Record\n2. All Record");
                                    ch = int.Parse(Console.ReadLine());
                                    int aid;
                                    if (ch == 1)
                                    {
                                        Console.WriteLine("Enter the Address Id");
                                        aid = int.Parse(Console.ReadLine());
                                        List<Address> cl = db.specfAddressRecord(aid).ToList<Address>();
                                        if (cl.Count == 0)
                                        {
                                            Console.WriteLine("Not Valid : Enter Correct Choice");
                                            Console.WriteLine("1 Insert\n2 Display\n3 Update\n4 Delete\n5 Exit");
                                            Console.WriteLine("Enter the choice");
                                            ch = int.Parse(Console.ReadLine());
                                        }
                                        else
                                        {
                                            Console.WriteLine("ID\tADDRESS-1\tADDRESS-2\tADDRESS-3\tPOSTAL CODE\tCITY NAME\tCOUNTRY NAME");
                                            Console.WriteLine("______________________________________________________________________________________________");
                                            foreach (Address c1 in db.specfAddressRecord(aid))
                                            {
                                                display(c1);
                                            }
                                        }
                                    }
                                    if (ch == 2)
                                    {
                                        Console.WriteLine("ID\tADDRESS-1\tADDRESS-2\tADDRESS-3\tPOSTAL CODE\tCITY NAME\tCOUNTRY NAME");
                                        Console.WriteLine("___________________________________________________________________________________________________");
                                        foreach (Address c1 in db.allAddressRecord())
                                        {
                                            display(c1);
                                        }
                                    }
                                    else
                                    {
                                        Console.WriteLine("Invalid Choice");
                                    }
                                    break;
                                case 4:
                                    Console.WriteLine("1. Specific Record\n2. All Record");
                                    ch = int.Parse(Console.ReadLine());
                                    int bid;
                                    if (ch == 1)
                                    {
                                        Console.WriteLine("Enter the Building Id");
                                        bid = int.Parse(Console.ReadLine());
                                        List<Building> cl = db.specfBuildingRecord(bid).ToList<Building>();
                                        if (cl.Count == 0)
                                        {
                                            Console.WriteLine("Not Valid : Enter Correct Choice");
                                            Console.WriteLine("1 Insert\n2 Display\n3 Update\n4 Delete\n5 Exit");
                                            Console.WriteLine("Enter the choice");
                                            ch = int.Parse(Console.ReadLine());
                                        }
                                        else
                                        {
                                            Console.WriteLine("ID\tFLOOR NUMBER\tLATITUDE\tLONGITUDE\tADDRESS\t\tPOSTAL CODE\tCITY NAME\tCOUNTRY NAME");
                                            Console.WriteLine("______________________________________________________________________________________________");
                                            foreach (Building c1 in db.specfBuildingRecord(bid))
                                            {
                                                display(c1);
                                            }
                                        }
                                    }
                                    if (ch == 2)
                                    {
                                        Console.WriteLine("ID\tFLOOR NUMBER\tLATITUDE\tLONGITUDE\tADDRESS\t\tPOSTAL CODE\tCITY NAME\tCOUNTRY NAME");
                                        Console.WriteLine("___________________________________________________________________________________________________");
                                        foreach (Building c1 in db.allBuildingRecord())
                                        {
                                            display(c1);
                                        }
                                    }
                                    else
                                    {
                                        Console.WriteLine("Invalid Choice");
                                    }
                                    break;
                                case 5:
                                    Console.WriteLine("1. Specific Record\n2. All Record");
                                    ch = int.Parse(Console.ReadLine());
                                    int rid;
                                    if (ch == 1)
                                    {
                                        Console.WriteLine("Enter the Building Id");
                                        rid = int.Parse(Console.ReadLine());
                                        List<Room> cl = db.specfRoomRecord(rid).ToList<Room>();
                                        if (cl.Count == 0)
                                        {
                                            Console.WriteLine("Not Valid : Enter Correct Choice");
                                            Console.WriteLine("1 Insert\n2 Display\n3 Update\n4 Delete\n5 Exit");
                                            Console.WriteLine("Enter the choice");
                                            ch = int.Parse(Console.ReadLine());
                                        }
                                        else
                                        {
                                            Console.WriteLine("ID\tNAME\t\tDESCRIPTION\tCAPACITY\t\tENABLED\tCITY\t\tCOUNTRY");
                                            Console.WriteLine("______________________________________________________________________________________________");
                                            foreach (Room c1 in db.specfRoomRecord(rid))
                                            {
                                                display(c1);
                                            }
                                        }
                                    }
                                    if (ch == 2)
                                    {
                                        Console.WriteLine("ID\tNAME\t\tDESCRIPTION\tCAPACITY\tENABLED\t\tCITY\t\tCOUNTRY");
                                        Console.WriteLine("___________________________________________________________________________________________________");
                                        foreach (Room c1 in db.allRoomRecord())
                                        {
                                            display(c1);
                                        }
                                    }
                                    else
                                    {
                                        Console.WriteLine("Invalid Choice");
                                    }
                                    break;
                            }
                        }
                        break;
                    case 3:
                        Console.WriteLine("\n1 Update Country\n2 Update City\n3 Update Address\n4 Update Building\n5 Update Room\n6 Main menu");
                        ch = int.Parse(Console.ReadLine());
                        while(ch!=6)
                        {
                            switch(ch)
                            {
                                case 1: Console.WriteLine("Enter the Country ID");
                                    int id = int.Parse(Console.ReadLine());
                                    cut = db.Countries.Find(id);
                                    if(cut==null)
                                    {
                                        Console.WriteLine("Country with specific id not exist");
                                    }
                                    else
                                    {
                                        Console.Write("Enter the Country Name = ");
                                        cut.CountryName = Console.ReadLine();
                                        db.SaveChanges();
                                    }
                                    break;
                                case 2:
                                    Console.WriteLine("Enter the City ID");
                                    id = int.Parse(Console.ReadLine());
                                    ct = db.Cities.Find(id);
                                    if (ct == null)
                                    {
                                        Console.WriteLine("City with specific id not exist");
                                    }
                                    else
                                    {
                                        Console.Write("Enter the City Name = ");
                                        ct.CityName = Console.ReadLine();
                                        db.SaveChanges();
                                    }
                                    break;
                                case 3:
                                    Console.WriteLine("Enter the City ID");
                                    id = int.Parse(Console.ReadLine());
                                    ad = db.Addresses.Find(id);
                                    if (ad == null)
                                    {
                                        Console.WriteLine("Address with specific id not exist");
                                    }
                                    else
                                    {
                                        Console.Write("Enter the Address1 = ");
                                        ad.Address1 = Console.ReadLine();
                                        Console.Write("Enter the Address2 = ");
                                        ad.Address1 = Console.ReadLine();
                                        Console.Write("Enter the Address3 = ");
                                        ad.Address1 = Console.ReadLine();
                                        Console.WriteLine("Enter the Postal Code");
                                        ad.PostalCode = Console.ReadLine();
                                        db.SaveChanges();
                                    }
                                    break;
                                case 4:
                                    Console.WriteLine("Enter the Building ID");
                                    id = int.Parse(Console.ReadLine());
                                    bi = db.Buildings.Find(id);
                                    if (bi == null)
                                    {
                                        Console.WriteLine("Building with specific id not exist");
                                    }
                                    else
                                    {
                                        Console.Write("Enter the FLOOR NUMBER = ");
                                        bi.FloorNumber =int.Parse(Console.ReadLine());
                                        Console.Write("Enter the LATITUDE = ");
                                        bi.Latitude = decimal.Parse(Console.ReadLine());
                                        Console.Write("Enter the LONGITUDE = ");
                                        bi.Longitude = decimal.Parse(Console.ReadLine());
                                        db.SaveChanges();
                                    }
                                    break;
                                case 5:
                                    Console.WriteLine("Enter the Room ID");
                                    id = int.Parse(Console.ReadLine());
                                    r = db.Rooms.Find(id);
                                    if (r == null)
                                    {
                                        Console.WriteLine("Building with specific id not exist");
                                    }
                                    else
                                    {
                                        Console.WriteLine("Enter the Owner name");
                                        r.name = Console.ReadLine();
                                        Console.WriteLine("Enter the Description");
                                        r.description = Console.ReadLine();
                                        Console.WriteLine("Enter the Capacity");
                                        r.capacity = int.Parse(Console.ReadLine());
                                        Console.WriteLine("Enter the Enabled");
                                        r.enabled = byte.Parse(Console.ReadLine());
                                        Console.WriteLine("Enter the note");
                                        r.note = Console.ReadLine();
                                        Console.WriteLine("Enter the Smart");
                                        r.smart = byte.Parse(Console.ReadLine());
                                        Console.WriteLine("Enter the Building ID");
                                        r.IdBuilding = int.Parse(Console.ReadLine());
                                        Console.WriteLine("Enter the Floor");
                                        r.floor = int.Parse(Console.ReadLine());
                                        Console.WriteLine("UPDATED SCCESSFULLY");
                                        db.SaveChanges();
                                    }
                                    break;
                            }
                        }
                        break;
                    case 4:
                        Console.WriteLine("\n1 Delete Country\n2 Delete City\n3 Delete Address\n4 Delete Building\n5 Delete Room\n6 Main menu");
                        ch = int.Parse(Console.ReadLine());
                        while(ch!=6)
                        {
                            switch (ch)
                            {
                                case 1:
                                    Console.WriteLine("Enter the Country ID");
                                    int id = int.Parse(Console.ReadLine());
                                    cut = db.Countries.Find(id);
                                    if (cut == null)
                                    {
                                        Console.WriteLine("Country with specific id not exist");
                                    }
                                    else
                                    {
                                        Console.WriteLine("Deleted Successfully");
                                        db.Countries.Remove(cut);
                                        db.SaveChanges();
                                    }
                                    break;
                                case 2:
                                    Console.WriteLine("Enter the City ID");
                                    id = int.Parse(Console.ReadLine());
                                    ct = db.Cities.Find(id);
                                    if (ct == null)
                                    {
                                        Console.WriteLine("City with specific id not exist");
                                    }
                                    else
                                    {
                                        Console.WriteLine("Deleted Successfully");
                                        db.Cities.Remove(ct);
                                        db.SaveChanges();
                                    }
                                    break;
                                case 3:
                                    Console.WriteLine("Enter the City ID");
                                    id = int.Parse(Console.ReadLine());
                                    ad = db.Addresses.Find(id);
                                    if (ad == null)
                                    {
                                        Console.WriteLine("Address with specific id not exist");
                                    }
                                    else
                                    {
                                        Console.WriteLine("Deleted Successfully");
                                        db.Addresses.Remove(ad);
                                        db.SaveChanges();
                                    }
                                    break;
                                case 4:
                                    Console.WriteLine("Enter the Building ID");
                                    id = int.Parse(Console.ReadLine());
                                    bi = db.Buildings.Find(id);
                                    if (bi == null)
                                    {
                                        Console.WriteLine("Building with specific id not exist");
                                    }
                                    else
                                    {
                                        Console.WriteLine("Deleted Successfully");
                                        db.Buildings.Remove(bi);
                                        db.SaveChanges();
                                    }
                                    break;
                                case 5:
                                    Console.WriteLine("Enter the Room ID");
                                    id = int.Parse(Console.ReadLine());
                                    r = db.Rooms.Find(id);
                                    if (r == null)
                                    {
                                        Console.WriteLine("Building with specific id not exist");
                                    }
                                    else
                                    {
                                        Console.WriteLine("Deleted Successfully");
                                        db.Rooms.Remove(r);
                                        db.SaveChanges();
                                    }
                                    break;
                            }
                        }
                        break;

                }
            } 
        }
    }
}
